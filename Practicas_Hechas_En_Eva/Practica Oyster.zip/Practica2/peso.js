const Moneda = require('./moneda.js');

const Peso = function (monto) {
    Moneda.call(this, monto);

    this.monto=monto;

    this.aPesos = function (){
        return this.monto;
    }

    this.aLibras = function() {
        return this.monto /  1830;
    }
}


Peso.prototype = Object.create(Moneda.prototype);
Peso.prototype.constructor = Peso;

module.exports = Peso;