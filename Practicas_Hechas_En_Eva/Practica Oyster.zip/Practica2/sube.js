const Tarjeta = require("./tarjeta.js")

class TarjetaSube extends Tarjeta {
    static SALDO_MINIMO = -600; 
    constructor(numeroDeIdentificador){
        super(numeroDeIdentificador);
        this.saldoMinimo = TarjetaSube.SALDO_MINIMO
    }

    convertir(monto){
        return monto.aPesos()
    }
}

module.exports = TarjetaSube