const Moneda = function (monto, divisa) {
    this.monto = monto;

    this.toString = function() {
        return `Moneda(${this.monto}, ${this.divisa})`;
    };

    this.aPesos = function() {
        throw new Error("Not implemented")
    }

    this.aLibras = function() {
        throw new Error("Not implemented")
    }
}

module.exports = Moneda;