const SistemaCentralizado = require("./sistemaCentralizado.js");
const TarjetaSube = require("./sube.js");
const Peso = require("./peso.js")
const Dolar = require("./dolar.js")
const Libra = require("./libra.js");
const TarjetaOyster = require("./oyster.js");


const sc = new SistemaCentralizado();
const sube = new TarjetaSube(1);
const oyster = new TarjetaOyster(2);


sc.cargarTarjeta(1, new Peso(770));
sc.cargarTarjeta(1, new Dolar(1));
sc.cargarTarjeta(1, new Libra(1));

sc.cargarTarjeta(2, new Peso(1830));
const cantidadDeLibrasACargar = 1;
sc.cargarTarjeta(2, new Dolar(cantidadDeLibrasACargar*1830/1400));
sc.cargarTarjeta(2, new Libra(1));

sc.cargarTarjeta(3, new Peso(100));

console.log("Monto acreditado: " + sc.montoTotalAcreditado());
console.log("Monto pendiente: " + sc.montoTotalPendiente());

sc.acreditarSaldo(sube);
sc.acreditarSaldo(sube);
sc.acreditarSaldo(oyster);


console.log("Monto acreditado: " + sc.montoTotalAcreditado());
console.log("Monto pendiente: " + sc.montoTotalPendiente());
console.log("Sube Saldo: " + sube.obtenerSaldo());
console.log("Oyster Saldo: " + oyster.obtenerSaldo());