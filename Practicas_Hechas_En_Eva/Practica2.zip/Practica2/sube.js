const Carga = require("./Carga.js")

class TarjetaSube {
    static SALDO_MINIMO = -600; 
    constructor(numeroDeIdentificador){
        this.saldo = 0;
        this.numeroDeIdentificador = numeroDeIdentificador
    }

    obtenerSaldo(){
        return this.saldo;
    }

    acreditarSaldo(montoACargar){
        this.saldo += montoACargar;
    }

    pagarViaje(precioDeViaje){
        if (this.saldo - precioDeViaje < TarjetaSube.SALDO_MINIMO) {
            throw new Error("Saldo insuficiente.");
        }
        
        this.saldo -= precioDeViaje;   
    }

    validarViaje(precioDeViaje) {
        if (this.saldo - precioDeViaje < TarjetaSube.SALDO_MINIMO) {
            throw new Error("Saldo insuficiente.");
        }
    }

    tenesId(id){
        return id === this.numeroDeIdentificador
    }
}


class SistemaCentralizado{
    constructor(){
        this.cargas = [];
    }

    acreditarSaldo(tarjetaSube){
        /*
        const cargasNoAcreditadas = this.cargas.filter(carga => 
            !carga.correspondeA(tarjetaSube)
        );
        this.cargas.filter(carga => 
            carga.correspondeA(tarjetaSube)
        ).forEach(carga => carga.cargar(tarjetaSube));
        this.cargas = cargasNoAcreditadas;
*/
        this.cargas
            .filter(carga => carga.correspondeA(tarjetaSube))
            .forEach(carga => carga.cargar(tarjetaSube));
    }

    cargarTarjeta(id, monto){
        if(monto < 0)
            throw new Error("Monto negativo");
        const carga=new Carga(id,monto);
        this.cargas.push(carga);
    }

    montoTotalAcreditado(){
        let total = 0;
        return this.cargas.reduce((total, carga) => total + carga.saldoAcreditado(), 0);
    }

    montoTotalPendiente(){
        let total = 0;
        return  this.cargas.reduce((total, carga) => total + carga.saldoPendiente(), 0);
    }
}


const sc = new SistemaCentralizado();
const sube = new TarjetaSube(1);


sc.cargarTarjeta(1, 100);
sc.cargarTarjeta(3, 100);

console.log("Monto acreditado: " + sc.montoTotalAcreditado());
console.log("Monto pendiente: " + sc.montoTotalPendiente());

sc.acreditarSaldo(sube);
sc.acreditarSaldo(sube);


console.log("Monto acreditado: " + sc.montoTotalAcreditado());
console.log("Monto pendiente: " + sc.montoTotalPendiente());